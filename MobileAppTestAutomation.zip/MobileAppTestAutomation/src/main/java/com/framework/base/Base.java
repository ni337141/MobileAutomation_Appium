package com.framework.base;

import org.openqa.selenium.WebDriver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class Base {

	
	private static ThreadLocal<AppiumDriver<MobileElement>> dr = new ThreadLocal<>();

	public static WebDriver getDriver() {
		return dr.get();
	}

	public static void setWebDriver(AppiumDriver<MobileElement> driver) {
		dr.set(driver);
	}

	

}
