package com.framework.base;


import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.framework.config.ConfigReader;
import com.framework.utilities.LogUtil;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class BaseTest extends Base {

	private static AppiumDriver<MobileElement> driver;
	ConfigReader reader;
	LogUtil logs;
	
	
	public void InitialiseBaseTest() {
		reader = new ConfigReader();
		reader.ReadProperty();
		logs = new LogUtil();
		logs.configureLogging();
	}

	
	public void LaunchApplication() {
		try	{
			if (ConfigReader.platformName.equalsIgnoreCase("Android")) { 
				try
				{
				DesiredCapabilities cap=new DesiredCapabilities();
				cap.setCapability("deviceName", ConfigReader.deviceName);
				cap.setCapability("udid", ConfigReader.udid);
				cap.setCapability("platformName", ConfigReader.platformName);
				cap.setCapability("platformVersion", ConfigReader.platformVersion);
				cap.setCapability("appPackage", ConfigReader.appPackage);
				cap.setCapability("appActivity", ConfigReader.appActivity);
				

				driver=new AppiumDriver<MobileElement>(new URL(ConfigReader.appiumServer),cap);
				Thread.sleep(5000);
				LogUtil.logInfo("Sucessfully Launched Application");
				} catch (Exception e) {
					LogUtil.logFailure("Error while Launching");
					e.printStackTrace();
					e.getCause();
					e.getMessage();
				}
			} else if (ConfigReader.platformName.equalsIgnoreCase("ios")) {
				//ios configuration

			}
		
		
		driver.manage().timeouts().implicitlyWait(ConfigReader.ImplicitWaitTime, TimeUnit.SECONDS);
		setWebDriver(driver);
		LogUtil.logInfo("Appium Initialised and application Launched successfully !!");
		} catch (Exception e) {
			LogUtil.logFailure("Exception Occured while launching application"+e.getMessage());
		}
	}

	public static void QuitDriver() {
		getDriver().quit();
		LogUtil.logInfo("Driver Quite");
	}

}
