package com.framework.listeners;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.util.ExceptionUtils;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.model.ExceptionInfo;
import com.framework.utilities.ExtentManager;



public class ExtentListeners implements ITestListener {

	private static ExtentTest extentTest = null;
	private static Map extentFeatureMap = new HashMap();
	private static Map extentScenarioMap = new HashMap();
	private static Map screenShotPathMap = new HashMap();
	private static Map gherkinNodeMap = new HashMap();
	private static ITestResult result;
	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
	static String Filepath = ExtentManager.createReportPath(System.getProperty("user.dir") + "\\reports").toString();
	private static ExtentReports extent = ExtentManager.createInstance(Filepath + "\\" + fileName);
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();

	@Override
	public synchronized void onTestStart(ITestResult result) {
		this.result=result;
	}

	@Override
	public synchronized void onTestSuccess(ITestResult result) {
		this.result=result;
	}

	@Override
	public synchronized void onTestFailure(ITestResult result) {
		this.result=result;
	}

	@Override
	public synchronized void onTestSkipped(ITestResult result) {
		this.result=result;
	}

	@Override
	public synchronized void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		System.out.println(" Test Percentage");
	}

	@Override
	public synchronized void onStart(ITestContext result) {
		System.out.println("On Test Start");
	}

	@Override
	public synchronized void onFinish(ITestContext result) {
		extent.flush();
	}

	public static synchronized String getScreenshotPath() {
		return (String) screenShotPathMap.get((int) (long) (Thread.currentThread().getId()));
	}

	public static synchronized void putScreenshotPath(String path) {
		screenShotPathMap.put((int) (long) (Thread.currentThread().getId()), path);
	}

	public static synchronized ExtentTest getFeature() {
		return (ExtentTest) extentFeatureMap.get((int) (long) (Thread.currentThread().getId()));
	}

	public static synchronized ExtentTest getScenario() {
		return (ExtentTest) extentScenarioMap.get((int) (long) (Thread.currentThread().getId()));
	}
	
	public static synchronized ExtentTest startFeature(String featureName) throws ClassNotFoundException {
		// ExtentTest test = extent.createTest(new GherkinKeyword("Feature"),
		// featureName);
		extentTest = extentTest.createNode(new GherkinKeyword("Feature"), featureName);
		extentFeatureMap.put((int) (long) (Thread.currentThread().getId()), extentTest);
		return extentTest;
	}

	
	public static synchronized ExtentTest startScenario(String scenarioName) {
		//extentTest = getFeature();
		extentTest = extentTest.createNode(Scenario.class, scenarioName);
		extentScenarioMap.put((int) (long) (Thread.currentThread().getId()), extentTest);
		return extentTest;
	}
	
	public static synchronized ExtentTest CreateGherkinNode(GherkinKeyword keyword, String name) {
		extentTest = getScenario();
		extentTest = extentTest.createNode(keyword, name);
		gherkinNodeMap.put((int) (long) (Thread.currentThread().getId()), extentTest);
		testReport.set(extentTest);
		return extentTest;
	}
	
	public static synchronized ExtentTest CreateTest(String scenarioName)
	{
		String methodName = scenarioName.split("-")[0];
		extentTest = extent
				.createTest(methodName+" : Automation Report");
		testReport.set(extentTest);
		return extentTest;
	}
	
	public static synchronized ExtentTest TestSuccess(String scenarioName)
	{
		String methodName = scenarioName.split("-")[0];
		String logText = "<b>" + "TEST CASE:- " + methodName.toUpperCase() + " PASSED" + "</b>";
		Markup m = MarkupHelper.createLabel(logText, ExtentColor.GREEN);
		testReport.get().pass(m);
		return extentTest;
	}
	
	public static synchronized ExtentTest TestFailure(String scenarioName)
	{
	try {
			ExtentManager.captureScreenshot();
			testReport.get().fail("<b>" + "<font color=" + "red>" + "Screenshot of failure" + "</font>" + "</b>", MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
		} catch (IOException e) {
			System.out.println("Error while caturing screenshot"+e.getMessage());
		}
		String methodName = scenarioName.split("-")[0];
		String logText = "<b>" + "Test Case:- " + methodName + " Failed" + "</b>";
		Markup m = MarkupHelper.createLabel(logText, ExtentColor.RED);
		testReport.get().log(Status.FAIL, m);
		return extentTest;
	}
	
	public static synchronized ExtentTest TestSkip(String scenarioName)
	{
		String methodName = scenarioName.split("-")[0];
		String logText = "<b>" + "Test Case:- " + methodName + " Skipped" + "</b>";
		Markup m = MarkupHelper.createLabel(logText, ExtentColor.YELLOW);
		testReport.get().skip(m);
		return extentTest;
	}
}
