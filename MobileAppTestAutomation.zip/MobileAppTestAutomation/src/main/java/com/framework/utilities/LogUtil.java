package com.framework.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.aventstack.extentreports.Status;
import com.framework.config.ConfigReader;
import com.framework.listeners.ExtentListeners;

public class LogUtil {

	static Date d ;
	static String fileName ;
	static String Filepath;
	String log4jConfigFile;
	public static Logger log;

	
	public void configureLogging() {
		try {
			d = new Date();
			fileName = "Log_" + d.toString().replace(":", "_").replace(" ", "_") + ".log";
			Filepath = ExtentManager.createReportPath(System.getProperty("user.dir") + "\\reports\\Logs").toString();
			File logFile = new File(Filepath + "\\" + fileName);
			FileWriter fileWriter = new FileWriter(logFile.getAbsoluteFile());

			log4jConfigFile = System.getProperty("user.dir") + "\\src\\main\\resources\\logs\\log4j.properties";
			Properties props = new Properties();
			InputStream configStream = new FileInputStream(log4jConfigFile);
			props.load(configStream);

			// configStream.close();
			props.setProperty("log4jfilename", logFile.getPath());
			LogManager.resetConfiguration();
			PropertyConfigurator.configure(props);
			log = Logger.getLogger(ConfigReader.platformName);
		} catch (IOException e) {
			System.out.println("Error While accessing Log file ");
		}
	}

	
	public static void logInfo(String message) {
		ExtentListeners.testReport.get().info(message);
		log.info(message);
	}
	public static void logFailure(String message) {
		ExtentListeners.testReport.get().fail(message);
		log.fatal(message);
	}

}
