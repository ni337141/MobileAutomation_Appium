package com.framework.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigReader {
	
	public static String appiumServer;
	public static String deviceName;
	public static String udid;
	public static String platformName;
	public static String platformVersion;
	public static String appPackage;
	public static String appActivity;
	public static long ImplicitWaitTime;
	public static String JsonTestData;

	public enum PlateformType {
		Android,iOS
	}

	
	
	public void ReadProperty() {
		// Create Property Object
		Properties p = new Properties();
		InputStream inputStream;
		try {
			inputStream = new FileInputStream(
					System.getProperty("user.dir") + "/src/main/resources/configuration/GlobalConfig.properties");
			p.load(inputStream);
		} catch (FileNotFoundException e) {
			System.out.println("Global Config File is not found");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error while loading data from config property File");
			e.printStackTrace();
		}

		appiumServer = p.getProperty("appiumServer");
		deviceName = p.getProperty("deviceName");
		udid=p.getProperty("udid");
		platformName = PlateformType.valueOf(p.getProperty("platformName")).toString();
		platformVersion = p.getProperty("platformVersion");
		appPackage = p.getProperty("appPackage");
		appActivity = p.getProperty("appActivity");
		ImplicitWaitTime = Long.parseLong(p.getProperty("ImplicitWait"));
		JsonTestData = p.getProperty("jsonTestData");
	}

}
