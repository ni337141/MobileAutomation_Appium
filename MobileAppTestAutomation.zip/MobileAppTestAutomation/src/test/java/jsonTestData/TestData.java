package jsonTestData;


public class TestData {

	public String UniqueID;
	public String UserName;
	public String Password;
	
	}

	