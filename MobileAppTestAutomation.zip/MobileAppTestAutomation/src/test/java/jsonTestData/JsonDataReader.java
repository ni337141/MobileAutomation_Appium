package jsonTestData;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.framework.config.ConfigReader;
import com.framework.utilities.LogUtil;
import com.google.gson.Gson;

public class JsonDataReader {
	private List<TestData> testData;

	public JsonDataReader() {
		testData = getData();
	}

	private List<TestData> getData() {
		Gson gson = new Gson();
		BufferedReader bufferReader = null;
		try {
			bufferReader = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/src/main/resources/JsonData/"+ConfigReader.JsonTestData));
			TestData[] data = gson.fromJson(bufferReader, TestData[].class);
			return Arrays.asList(data);
		} catch (FileNotFoundException e) {
			LogUtil.logFailure("Json file not found at path : " + ConfigReader.JsonTestData);
			throw new RuntimeException("Json file not found at path : " + ConfigReader.JsonTestData);
		} finally {
			try {
				if (bufferReader != null)
					bufferReader.close();
			} catch (IOException ignore) {
			}
		}
	}

	public final TestData getDataByUniqueID(String UniqueID) {
		return testData.stream().filter(x -> x.UniqueID.equalsIgnoreCase(UniqueID)).findAny().get();
	}

}