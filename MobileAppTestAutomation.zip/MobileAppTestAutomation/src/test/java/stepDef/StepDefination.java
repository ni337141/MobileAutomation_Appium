package stepDef;

import com.aventstack.extentreports.GherkinKeyword;
import com.framework.base.BaseTest;
import com.framework.listeners.ExtentListeners;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import jsonTestData.JsonDataReader;
import jsonTestData.TestData;
import pages.HomePage;
import pages.LoginPage;


public class StepDefination extends BaseTest {

	TestData data;
	JsonDataReader jsonreader;
	LoginPage login;
	HomePage homepage;
	
	
	@Given("^User is on Application$")
	public void user_is_on_Application() throws Throwable {
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("Given"), "User is on Application");
		login=new LoginPage();
		login.VerifyApplicationisLaunched();
	}
	@When("^User Click on Login Link$") 
	public void User_Click_on_Login_Link() throws Throwable 
	{
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("When"), "User Click on Login Link");
		login.clickOnLoginLink();
	}
	
	@Then("^User is on LoginPage and Initialized testData of '(.*?)'$")
	public void userLoggedIn_InitializedTestData(String UniqueID) throws Throwable {
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("Then"), "User is on LoginPage and Initialized testData of "+UniqueID);
		jsonreader = new JsonDataReader();
		data = jsonreader.getDataByUniqueID(UniqueID);
		login.VerifyLoginPage();
	}
	@When("^User Enter username and password and perform Login$")
	public void user_is_on_Login_Page() throws Throwable {
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("When"), "User Enter username and password and perform Login");
		homepage=login.Login(data.UserName, data.Password);
	}
	@Then("^Verify Dashboard$")
	public void user_Redirected_to_Homepage_and_Welcome_screen_displayed() throws Throwable {
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("Then"),"Verify Dashboard");
		homepage.DeleteSession();
		homepage.VerifyDashboard();
	}
	@And("^LogOut$")
	public void Logout() throws Throwable
	{
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("And"), "LogOut");
		homepage.LogOut();
	}
	@Then("^Verify alert with invaliddetails$")
	public void invaliddetails() throws Throwable
	{
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("Then"),"Verify alert with invaliddetails");
		login.VerifyPopupWithInvalidDetails();
	}
	@Then("^Verify Blank Field Error$")
	public void BlanklFieldError() throws Throwable
	{
		ExtentListeners.CreateGherkinNode(new GherkinKeyword("Then"),"Verify Blank Field Error");
		login.verifyBlankfieldError();
	}

}
