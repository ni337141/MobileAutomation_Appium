package stepDef;


import com.framework.base.BaseTest;
import com.framework.listeners.ExtentListeners;
import com.framework.utilities.LogUtil;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class TestInitialize extends BaseTest {

	@Before
	public synchronized void Initialize(Scenario scenario) {
		ExtentListeners.CreateTest(scenario.getName());
		ExtentListeners.startScenario(scenario.getName());
		InitialiseBaseTest();
		LaunchApplication();
	}

	@After
	public void TearDown(Scenario scenario) {
		// One of "passed", "undefined", "pending", "skipped", "failed"
		if (scenario.isFailed())
			ExtentListeners.TestFailure(scenario.getName());
			else if (scenario.getStatus().equals("passed"))
			ExtentListeners.TestSuccess(scenario.getName());
		else if (scenario.getStatus().equals("skipped"))
			ExtentListeners.TestSkip(scenario.getName());
		else {
			ExtentListeners.testReport.get().info("Scenario " + scenario.getName() + " is " + scenario.getStatus());
			LogUtil.logInfo("Scenario " + scenario.getName() + " is Completed");
		}
		QuitDriver();
	}
}
