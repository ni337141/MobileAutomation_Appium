package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.framework.base.Base;
import com.framework.utilities.LogUtil;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginPage extends Base {

	@FindBy(xpath = "//*[@text='Ingia']")
	private MobileElement link_Login;

	@FindBy(xpath = "//*[@text='Msimbo wa Nchi']/following-sibling::android.view.ViewGroup/android.widget.ImageView")
	private MobileElement dropdown_country;
	
	@FindBy(xpath = "//*[@text='Tanzania']")
	private MobileElement Country;
	
	@FindBy(xpath = "//*[@text='Msimbo wa Nchi']/following-sibling::android.widget.EditText[1]")
	private MobileElement txt_UserName;
	
	@FindBy(xpath = "//*[@text='Msimbo wa Nchi']/following-sibling::android.widget.EditText[2]")
	private MobileElement txtPassowrd;
	
	@FindBy(xpath = "//*[@text='Nimesahau Nywila']/../following::android.widget.TextView[@text='Ingia']")
	private MobileElement butto_login;
	
	@FindBy(xpath = "//*[@text='KOSA']")
	private MobileElement popup;
	@FindBy(xpath = "//*[@text='undefined']")
	private MobileElement undefined;
	@FindBy(xpath = "//*[@text='Ondoa']")
	private MobileElement button_ok;
	public LoginPage()
	{
		PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
	}
	public HomePage Login(String userid,String password) {
		LogUtil.logInfo("Logging to Application");
		dropdown_country.click();
		Country.click();
		txt_UserName.sendKeys(userid);
		txtPassowrd.sendKeys(password);
		butto_login.click();
		if(getDriver().findElements(By.id("com.android.packageinstaller:id/permission_allow_button")).size()>0)	{
			getDriver().findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();
			LogUtil.logInfo("Location Allow Popup appeared");
		}
		return new HomePage();
	}

	public void VerifyLoginPage() {
		if(txt_UserName.isDisplayed())
			LogUtil.logInfo("Login Page Verified Succesfully");
	}
	public void clickOnLoginLink()
	{
		link_Login.click();
		LogUtil.logInfo("Clicked on login link");
	}
	public void VerifyApplicationisLaunched()
	{
		if(link_Login.isDisplayed())
			LogUtil.logInfo("Sucessfully Application is launched");
		else
			Assert.assertTrue(false, "Application is not Launched yet");
	}
	public void verifyBlankfieldError()
	{
		if(getDriver().findElements(By.xpath("//*[@text='Tafadhali ingiza herufi/tarakimu']")).size()==2)
			LogUtil.logInfo("Blank filed Error verified successfully");
		else
			Assert.assertTrue(false, "Blank field error is not diplayed");
	}
	public void VerifyPopupWithInvalidDetails()
	{
		if(button_ok.isDisplayed())
		{
			LogUtil.logInfo("Successfully verified alert popup");
			button_ok.click();
		}
		else
			Assert.assertTrue(false, "Invalid details error is not displayed");
	}
}
