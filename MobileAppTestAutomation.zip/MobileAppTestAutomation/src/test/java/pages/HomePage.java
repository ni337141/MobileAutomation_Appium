package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.framework.base.Base;
import com.framework.utilities.LogUtil;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePage extends Base {

	@FindBy(xpath = "//android.widget.TextView[@text='']")
	private MobileElement link_Menu;
	@FindBy(xpath = "//android.widget.TextView[@text='Makundi ya juu']")
	private MobileElement button_setting;
	@FindBy(xpath = "//android.widget.TextView[@text='ONDOKA']")
	private MobileElement button_LogOut;
	@FindBy(xpath = "//android.widget.TextView[@text='THIBITISHA']")
	private MobileElement button_COnfirm;
	
	HomePage()
	{
		PageFactory.initElements(new AppiumFieldDecorator(getDriver()), this);
	}

	public void LogOut() {
		link_Menu.click();
		button_setting.click();
		button_LogOut.click();
		button_COnfirm.click();
		LogUtil.logInfo("Logged out from Application");
	}
	
	public void DeleteSession()
	{
		try
		{
			if(getDriver().findElements(By.xpath("//*[@text='Ondoa']")).size()>0)
			{
				LogUtil.logInfo("Session need to be deleted");
			getDriver().findElement(By.xpath("//*[@text='Ondoa']")).click();
			Thread.sleep(2000);
			getDriver().findElement(By.xpath("//*[@text='Delete']")).click();
			Thread.sleep(2000);
			LogUtil.logInfo("Deleted Session");	
			}
			} catch (Exception e) {
			LogUtil.logFailure("Error while Login");
			e.printStackTrace();
			e.getCause();
			e.getMessage();
			}
	}
	public void VerifyDashboard()
	{
		try
		{
		Thread.sleep(5000);
		if(getDriver().findElements(By.xpath("//android.widget.Button[@content-desc='Maskani, tab, 1 of 4']/android.widget.TextView[1]")).size()>0)
			LogUtil.logInfo("Sucessfully verified Dashboard");
		else
			Assert.assertTrue(false, "User is not on Dashboard");
		
		} catch (Exception e) {
			LogUtil.logFailure("Error while Verifying Dashboard");
			e.printStackTrace();
			e.getCause();
			e.getMessage();
		}
	}
}
