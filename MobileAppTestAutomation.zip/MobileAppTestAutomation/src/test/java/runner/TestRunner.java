package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;


import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.framework.base.BaseTest;
import com.framework.listeners.ExtentListeners;



@CucumberOptions(features = {"src/main/resources/features/"},tags= {"@test"}, glue = {"stepDef"}, plugin = {"json:target/cucumber-json-report.json", "html:target/cucumber-report-html"})
public class TestRunner {


    private TestNGCucumberRunner testNGCucumberRunner;

    @BeforeClass(alwaysRun = true)
    public void setUpClass() {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }


    @Test(dataProvider = "features")
	public void RunTest(CucumberFeatureWrapper cucumberFeatureWrapper) throws ClassNotFoundException {
        var featureName = cucumberFeatureWrapper.getCucumberFeature().getGherkinFeature().getName();
        testNGCucumberRunner.runCucumber(cucumberFeatureWrapper.getCucumberFeature());
    }

    @DataProvider
    public Object[] features(ITestContext context) {
        var featureName = testNGCucumberRunner.provideFeatures();
        Object[] getFeature = null;
        for(var item : featureName){
            if(item[0].toString().equalsIgnoreCase(context.getName())){
                getFeature = item;
            }
        }
        return getFeature;
    }

    @AfterClass(alwaysRun = true)
    public void afterClass() {
        testNGCucumberRunner.finish();
        }

}
