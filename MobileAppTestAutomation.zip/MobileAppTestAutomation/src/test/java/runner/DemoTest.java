package runner;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class DemoTest {

	private static AppiumDriver<MobileElement> driver;
	
	public static void Setup()
	{
		try
		{
		DesiredCapabilities cap=new DesiredCapabilities();
		cap.setCapability("deviceName", "Redmi");
		cap.setCapability("udid", "14870a33");
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "9");
		cap.setCapability("appPackage", "com.azam.sarafu");
		cap.setCapability("appActivity", "com.azam.sarafu.MainActivity");
		

		driver=new AppiumDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		Thread.sleep(5000);
		System.out.println("Launched Application");
		} catch (Exception e) {
			System.out.println("Error while Launching");
			e.printStackTrace();
			e.getCause();
			e.getMessage();
		}
	}
	
	public static void Login()
	{
		try
		{
		driver.findElement(By.xpath("//*[@text='Ingia']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@text='Msimbo wa Nchi']/following-sibling::android.view.ViewGroup/android.widget.ImageView")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@text='Tanzania']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@text='Msimbo wa Nchi']/following-sibling::android.widget.EditText[1]")).sendKeys("710100021");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@text='Msimbo wa Nchi']/following-sibling::android.widget.EditText[2]")).sendKeys("12345");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@text='Nimesahau Nywila']/../following::android.widget.TextView[@text='Ingia']")).click();
		Thread.sleep(5000);
		if(driver.findElements(By.id("com.android.packageinstaller:id/permission_allow_button")).size()>0)
			driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();
		Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("Error while Login");
			e.printStackTrace();
			e.getCause();
			e.getMessage();
		}
	}
	public static void VerifyDashboard()
	{
		try
		{
		Thread.sleep(5000);
		if(driver.findElements(By.xpath("//android.widget.Button[@content-desc='Maskani, tab, 1 of 4']/android.widget.TextView[1]")).size()>0)
			System.out.println("Sucessfully verified Dashboard");
		else
			Assert.assertTrue(false, "User is not on Dashboard");
		
		} catch (Exception e) {
			System.out.println("Error while Verifying Dashboard");
			e.printStackTrace();
			e.getCause();
			e.getMessage();
		}
	}
	
	public static void LogOut()
	{
		try
		{
		driver.findElement(By.xpath("//android.widget.TextView[@text='']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//android.widget.TextView[@text='Makundi ya juu']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//android.widget.TextView[@text='ONDOKA']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//android.widget.TextView[@text='THIBITISHA']")).click();
		Thread.sleep(5000);
		} catch (Exception e) {
			System.out.println("Error while Logout");
			e.printStackTrace();
			e.getCause();
			e.getMessage();
		}
	}
	public static void DeleteSession()
	{
		try
		{
			if(driver.findElements(By.xpath("//*[@text='Ondoa']")).size()>0)
			{
			System.out.println("Session need to be deleted");
			driver.findElement(By.xpath("//*[@text='Ondoa']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@text='Delete']")).click();
			Thread.sleep(2000);
			System.out.println("Logging again");
			Login();
			
			}
			} catch (Exception e) {
			System.out.println("Error while Login");
			e.printStackTrace();
			e.getCause();
			e.getMessage();
			}
	}
	public static void main(String[] args)  {
	Setup();
	Login();
	DeleteSession();
	VerifyDashboard();
	LogOut();
	System.out.println("Done!!");
	}

}
